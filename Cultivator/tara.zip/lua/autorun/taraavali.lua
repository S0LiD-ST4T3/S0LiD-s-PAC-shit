	list.Set( "PlayerOptionsModel", "TaraAvaliPlayermodel", "models/player/TaraAvaliPlayermodel/TaraAvaliPlayermodel.mdl" )
	player_manager.AddValidModel( "TaraAvaliPlayermodel", "models/player/TaraAvaliPlayermodel/TaraAvaliPlayermodel.mdl" )
	player_manager.AddValidHands( "TaraAvaliPlayermodel", "models/weapons/arms/TaraAvaliArms.mdl", 0, "00000000" )
	
	AddCSLuaFile( "TaraAvali.lua" )

