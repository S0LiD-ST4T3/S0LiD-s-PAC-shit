list.Set( "PlayerOptionsModel", "Tracker ", "models/player/LeymiRBA/TrackerPM.mdl" )
player_manager.AddValidModel( "Tracker ", "models/player/LeymiRBA/TrackerPM.mdl" )
player_manager.AddValidHands( "Tracker ", "models/player/LeymiRBA/TrackerArms.mdl", 0, "00000000" )




